package com.example.tcp;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;

public class MainActivity extends AppCompatActivity {

    private TextView serverStatus;//يعرض حالة السيرفر أو الرسالة المستلمة.


    private EditText messageInput;// المستخدم يكتب فيه الرسالة
    private Button startServerBtn, sendMessageBtn; //لتشغيل السيرفر, لإرسال الرسالة للسيرفر.

    private ServerSocket serverSocket;
    private Socket clientSocket;

    private final int PORT = 4446;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverStatus = findViewById(R.id.serverStatus);
        messageInput = findViewById(R.id.messageInput);
        startServerBtn = findViewById(R.id.startServerBtn);
        sendMessageBtn = findViewById(R.id.sendMessageBtn);

        // زر تشغيل السيرفر
        startServerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startServer();
            }
        });

        // زر إرسال الرسالة
        sendMessageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    // تشغيل السيرفر
    private void startServer() {
        Thread serverThread = new Thread(() -> { //نشئ Thread (لأن الشبكة ما تنفع في Main Thread).
            try {
                serverSocket = new ServerSocket(PORT); //تنشئ ServerSocket على البورت 4446.
                runOnUiThread(() -> serverStatus.setText("✅ Server started on port " + PORT));

                while (true) {
                    Socket socket = serverSocket.accept();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String receivedMessage = reader.readLine();
//لما يستقبل اتصال

//يقرأ الرسالة من العميل باستخدام BufferedReader

//يعرضها في TextView
                    runOnUiThread(() -> serverStatus.setText("📩 Received: " + receivedMessage));

                    reader.close();
                    socket.close();
                    //يغلق الاتصال.
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        serverThread.start();
    }

    // إرسال رسالة كعميل
    private void sendMessage() {
        Thread clientThread = new Thread(() -> { //يدير تريد تاني
            try {
                // الاتصال بالسيرفر في نفس الجهاز باستخدام "localhost"
                clientSocket = new Socket("127.0.0.1", PORT);//يتصل بالسيرفر المحلي بنفس البورت
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);
                String message = messageInput.getText().toString();
                writer.println(message);

                writer.close();
                clientSocket.close();

                runOnUiThread(() -> Toast.makeText(MainActivity.this, "✅ Message Sent", Toast.LENGTH_SHORT).show());

            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "❌ Error sending message", Toast.LENGTH_SHORT).show());
            }
        });
        clientThread.start();
    }
}
//تعليقات باش ما ننساش مفهوم الكود ال درته
// مايدعمش اتصال على جهاازين مختلفين
//لان درته ع اساس خادم وعميل ف نفس الجهاز
//علاش استخدمت التريد
//عمليات الشبكة  لازم تكون في Thread خارجي باش برنامجي ما يعلقش
//كيف يتعامل السيرفر مع أكثر من رسالة
// السيرفر داخل while(true) يعني يستقبل أكتر من رسالة (لكن كل مرة يسكر الـ socket، ما يحتفظش بالاتصال).