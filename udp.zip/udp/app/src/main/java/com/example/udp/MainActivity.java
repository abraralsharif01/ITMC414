package com.example.udp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.cardview.widget.CardView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class MainActivity extends AppCompatActivity {

    Button sendBtn;
    TextView receivedMessage;
    CardView messageCard;
    EditText inputEditText;

    final int PORT = 3345;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendBtn = findViewById(R.id.sendBtn);
        receivedMessage = findViewById(R.id.receivedMessage);
        messageCard = findViewById(R.id.messageCard);
        inputEditText = findViewById(R.id.inputEditText);

        startUDPServer();

        sendBtn.setOnClickListener(v -> {
            String message = inputEditText.getText().toString().trim();
            if (!message.isEmpty()) {
                sendUDPMessage(message);
            } else {
                Toast.makeText(this, "الرجاء إدخال رسالة", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendUDPMessage(String message) {
        new Thread(() -> {
            try {
                DatagramSocket socket = new DatagramSocket();
                InetAddress address = InetAddress.getByName("127.0.0.1");

                byte[] data = message.getBytes();
                DatagramPacket packet = new DatagramPacket(data, data.length, address, PORT);
                socket.send(packet);
                socket.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void startUDPServer() {
        new Thread(() -> {
            try {
                DatagramSocket serverSocket = new DatagramSocket(PORT);
                byte[] buffer = new byte[1024];

                while (true) {
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    serverSocket.receive(packet);
                    String message = new String(packet.getData(), 0, packet.getLength());

                    runOnUiThread(() -> {
                        messageCard.setVisibility(View.VISIBLE);
                        receivedMessage.setText("📩 تم الاستلام: " + message);
                    });
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
